#!/usr/bin/python
import cv2
import numpy as np
import rospy
from color_blob_detection.msg import ColorMsg

HUE = 0
SATURATION = 1
VALUE = 2


class Color_Blob_Tracker(object):

    def __init__(self):
        self.blur = 5
        self.lower_bound = np.array([0, 50, 50])
        self.upper_bound = np.array([179, 255, 255])
        self.showVideo = True

        self._lower_bound_name = ["Hue Lower Bound",
                                  "Saturation Lower Bound", "Value Lower Bound"]
        self._upper_bound_name = ["Hue Upper Bound",
                                  "Saturation Upper Bound", "Value Upper Bound"]
        self._ros_init()
        self._video_init()

    def _ros_init(self):
        rospy.init_node('color_blob_tracker', anonymous=False)
        self.blob_loc_pub = rospy.Publisher(
            'color_blob', ColorMsg, queue_size=1)
        self.showVideo = rospy.get_param('~show_video', default=True)

    def _video_init(self):
        if self.showVideo:
            cv2.namedWindow("Track Bars")
            cv2.namedWindow("Video")
            cv2.createTrackbar("Blur", "Track Bars",
                               self.blur, 151, self.update_blur)
            cv2.createTrackbar("Hue Lower Bound", "Track Bars",
                               0, 179, self.update_sliders)
            cv2.createTrackbar("Hue Upper Bound", "Track Bars",
                               179, 179, self.update_sliders)

            cv2.createTrackbar("Saturation Lower Bound",
                               "Track Bars", 50, 255, self.update_sliders)
            cv2.createTrackbar("Saturation Upper Bound",
                               "Track Bars", 255, 255, self.update_sliders)

            cv2.createTrackbar("Value Lower Bound",
                               "Track Bars", 50, 255, self.update_sliders)
            cv2.createTrackbar("Value Upper Bound",
                               "Track Bars", 255, 255, self.update_sliders)
        device = rospy.get_param('~video_device', default=0)
        self.cam = cv2.VideoCapture(device)

    def update_sliders(self, _value):
        self.lower_bound = np.array(
            [cv2.getTrackbarPos(name, "Track Bars") for name in self._lower_bound_name])
        self.upper_bound = np.array(
            [cv2.getTrackbarPos(name, "Track Bars") for name in self._upper_bound_name])

    def update_blur(self, value):
        if value % 2 == 1:
            self.blur = value
        else:
            self.blur = value + 1

    def run(self):
        while not rospy.is_shutdown():
            ret_val, image = self.cam.read()

            if ret_val:
                blurred_image = cv2.medianBlur(image, self.blur)
                hsv_imgage = cv2.cvtColor(blurred_image, cv2.COLOR_BGR2HSV)
                mask = cv2.inRange(
                    hsv_imgage, self.lower_bound, self.upper_bound)
                _, contours, _ = cv2.findContours(
                    mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

                for i in xrange(0, len(contours)):
                    if cv2.contourArea(contours[i]) > 0:
                        msg = ColorMsg()

                        mask[...] = 0
                        cv2.drawContours(mask, contours, i, 255, -1)

                        color = cv2.mean(hsv_imgage, mask)
                        msg.v = int(color[2])
                        msg.s = int(color[1])
                        msg.h = int(color[0])

                        moment = cv2.moments(contours[i])
                        msg.x = moment["m10"] / moment["m00"]
                        msg.y = moment["m01"] / moment["m00"]

                        self.blob_loc_pub.publish(msg)

                if self.showVideo:
                    cv2.drawContours(image, contours, -1, (0, 0, 255))
                    cv2.imshow("Video", image)

                if cv2.waitKey(1) == 27:
                    break
        cv2.destroyAllWindows()


if __name__ == '__main__':
    TRACKER = Color_Blob_Tracker()
    TRACKER.run()
    rospy.spin()
