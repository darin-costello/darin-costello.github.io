#!/usr/bin/python
import rospy
import cv2
import numpy as np
from sphero_location.msg import SpheroLocation
from sphero_swarm.srv import ListSphero
from sphero_swarm.msg import Color
from std_msgs.msg import ColorRGBA
from color_blob_detection.msg import ColorMsg


def sum_sq_diff(array1, array2):
    """Given to arrays of equal size returns the sum of the square difference between them"""
    assert len(array1) == len(array2)
    total = 0
    for i in range(0, len(array1)):
        total += (array1[i] - array2[i]) ** 2
    return total


class SpheroLocatorColorBlob(object):

    def __init__(self):
        self._threshold = 50000
        self._sphero_to_color = {}
        self._ros_init()
        self._init_spheros()
        return

    def _ros_init(self):
        rospy.init_node('sphero_locator_color_blob')
        self.color_pub = rospy.Publisher(
            'set_color', Color, queue_size=1)
        self.pos_pub = rospy.Publisher(
            'sphero_location', SpheroLocation, queue_size=1)
        return

    def _init_spheros(self):
        end_color = {}
        rospy.sleep(1)
        rospy.wait_for_service('list_spheros')
        list_spheros = rospy.ServiceProxy('list_spheros', ListSphero)
        spheros = list_spheros().name
        size = len(spheros)
        hsv_max = 179.0
        step = hsv_max / size
        hue = 0.0
        self._threshold = step / 3.0
        for name in spheros:
            print name
            self._turn_off_sphero_light(name)
            rospy.sleep(0.125)
        rospy.sleep(1)

        for name in spheros:
            actual_hue = self._auto_adjust_sphero_color(name, hue)
            self._sphero_to_color[name] = hue
            self._turn_off_sphero_light(name)
            rospy.sleep(1)
            end_color[name] = actual_hue
            hue += step

        for name in spheros:
            self._publish_new_color(name, end_color[name])
            rospy.sleep(0.125)
        self.blob_loc_list = rospy.Subscriber('color_blob', ColorMsg,
                                              self._blob_location_listener, queue_size=20)
        return

    def _calc_color_error(self, intended, actual):
        if abs(intended - actual) <= abs(180.0 + intended - actual):
            return intended - actual
        else:
            return 180.0 + intended - actual

    def _auto_adjust_sphero_color(self, sphero_name, intended_hue, hue_max=179):
        print intended_hue
        current_hue = intended_hue
        self._publish_new_color(sphero_name, current_hue)
        previous_error = 0.0
        error_factor = 0.06
        delta_factor = 0.09
        color = rospy.wait_for_message("color_blob", ColorMsg)
        error = self._calc_color_error(intended_hue, color.h)
        correct_iterations = 0
        while correct_iterations < 3:

            error_change = error - previous_error
            print "sphero_name {}\tIntended {}\tCurrent {}\tError {}\t deltaError {}".format(sphero_name, intended_hue, current_hue, error, error_change)
            previous_error = error
            current_hue += (error_factor * error) + \
                (delta_factor * error_change)
            # current_hue += error
            current_hue = current_hue % hue_max
            self._publish_new_color(sphero_name, current_hue)
            rospy.sleep(0.125)
            color = rospy.wait_for_message("color_blob", ColorMsg)
            error = self._calc_color_error(intended_hue, color.h)
            if abs(error) <= self._threshold:
                correct_iterations += 1
            else:
                correct_iterations = 0
        return current_hue

    def _turn_off_sphero_light(self, sphero):
        msg = Color(sphero, ColorRGBA(0, 0, 0, 0))
        self.color_pub.publish(msg)
        return

    def _publish_new_color(self, name, hue):
        color = [int(hue), 255, 255]
        color = np.uint8([[color]])
        rgb = cv2.cvtColor(color, cv2.COLOR_HSV2RGB)[0][0]
        msg = Color(name, ColorRGBA(rgb[0], rgb[1], rgb[2], 255))
        self.color_pub.publish(msg)
        return

    def _blob_location_listener(self, color_msg):
        min_value = 10000000
        min_name = ""
        detected = color_msg.h
        for name, hue in self._sphero_to_color.iteritems():
            # diff = sum_sq_diff(detected , value)
            diff = abs(detected - hue)

            if diff < min_value:
                min_value = diff
                min_name = name

        if min_value < self._threshold:
            msg = SpheroLocation()
            msg.name = min_name
            msg.center_x = color_msg.x

            msg.center_y = color_msg.y
            self.pos_pub.publish(msg)
        return


if __name__ == '__main__':
    L = SpheroLocatorColorBlob()
    rospy.spin()
